package com.rishi.tempbox

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
