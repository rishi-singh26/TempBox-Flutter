class AppConstatns {
  static const appVersion = 'Version 1.2.6';
  static const String resetAppData =
      'Are you sure you want to reset app data?\nThis will delete all addresses and all emails received on those addresses.\n\nThis action is irreversible.';
}
